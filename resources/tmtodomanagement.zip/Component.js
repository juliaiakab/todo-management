sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("tm.todomanagement.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map